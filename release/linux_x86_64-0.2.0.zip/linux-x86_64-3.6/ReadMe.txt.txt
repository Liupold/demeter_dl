run the following cmd

chmod +x cli
./cli